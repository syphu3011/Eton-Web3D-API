<?php
$databases['default']['default'] = array (
  'database' => 'Eton-Web3D',
  'username' => 'postgres',
  'password' => '',
  'prefix' => '',
  'host' => 'localhost',
  'port' => '5432',
  'namespace' => 'Drupal\\pgsql\\Driver\\Database\\pgsql',
  'driver' => 'pgsql',
  'autoload' => 'core/modules/pgsql/src/Driver/Database/pgsql/',
);
$settings['config_sync_directory'] = 'sites/default/files/config_jk_Iyt8HKpkssxsAkgndyo7Jo895F8kY6Y6AzPNu8lz0IeaLaUsUzJmNyG3_ajqhmlX7xMvPJw/sync';
?>